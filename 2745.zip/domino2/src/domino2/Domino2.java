
package domino2;

public class Domino2 {

    public static void main(String[] args) {
        Start start = new Start();
        start.setVisible(true);
    }
    
}
