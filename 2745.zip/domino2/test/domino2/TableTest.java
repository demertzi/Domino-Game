/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class TableTest {
    
    public TableTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDominos method, of class Table.
     */
    @Test
    public void testGetDominos() {
        System.out.println("getDominos");
        Table instance = new Table();
        List<Tile> expResult = null;
        List<Tile> result = instance.getDominos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLeftSide method, of class Table.
     */
    @Test
    public void testGetLeftSide() {
        System.out.println("getLeftSide");
        Table instance = new Table();
        int expResult = 0;
        int result = instance.getLeftSide();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRightSide method, of class Table.
     */
    @Test
    public void testGetRightSide() {
        System.out.println("getRightSide");
        Table instance = new Table();
        int expResult = 0;
        int result = instance.getRightSide();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isEmpty method, of class Table.
     */
    @Test
    public void testIsEmpty() {
        System.out.println("isEmpty");
        Table instance = new Table();
        boolean expResult = false;
        boolean result = instance.isEmpty();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of numDomTable method, of class Table.
     */
    @Test
    public void testNumDomTable() {
        System.out.println("numDomTable");
        Table instance = new Table();
        int expResult = 0;
        int result = instance.numDomTable();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addDominoLeft method, of class Table.
     */
    @Test
    public void testAddDominoLeft() {
        System.out.println("addDominoLeft");
        Tile addedDom = null;
        boolean side1 = false;
        Table instance = new Table();
        instance.addDominoLeft(addedDom, side1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addDominoRight method, of class Table.
     */
    @Test
    public void testAddDominoRight() {
        System.out.println("addDominoRight");
        Tile addedDom = null;
        boolean side1 = false;
        Table instance = new Table();
        instance.addDominoRight(addedDom, side1);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTable method, of class Table.
     */
    @Test
    public void testPrintTable() {
        System.out.println("printTable");
        Table instance = new Table();
        instance.printTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
