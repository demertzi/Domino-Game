/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class TileTest {
    
    public TileTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getSide1 method, of class Tile.
     */
    @Test
    public void testGetSide1() {
        System.out.println("getSide1");
        Tile instance = new Tile();
        int expResult = 0;
        int result = instance.getSide1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSide2 method, of class Tile.
     */
    @Test
    public void testGetSide2() {
        System.out.println("getSide2");
        Tile instance = new Tile();
        int expResult = 0;
        int result = instance.getSide2();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isBlank method, of class Tile.
     */
    @Test
    public void testIsBlank() {
        System.out.println("isBlank");
        Tile instance = new Tile();
        boolean expResult = false;
        boolean result = instance.isBlank();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of blankIt method, of class Tile.
     */
    @Test
    public void testBlankIt() {
        System.out.println("blankIt");
        Tile instance = new Tile();
        instance.blankIt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of flip method, of class Tile.
     */
    @Test
    public void testFlip() {
        System.out.println("flip");
        Tile instance = new Tile();
        boolean expResult = false;
        boolean result = instance.flip();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of flipTile method, of class Tile.
     */
    @Test
    public void testFlipTile() {
        System.out.println("flipTile");
        Tile instance = new Tile();
        instance.flipTile();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalValue method, of class Tile.
     */
    @Test
    public void testGetTotalValue() {
        System.out.println("getTotalValue");
        Tile instance = new Tile();
        int expResult = 0;
        int result = instance.getTotalValue();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sameValue method, of class Tile.
     */
    @Test
    public void testSameValue() {
        System.out.println("sameValue");
        Tile comp = null;
        Tile instance = new Tile();
        boolean expResult = false;
        boolean result = instance.sameValue(comp);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of sameTile method, of class Tile.
     */
    @Test
    public void testSameTile() {
        System.out.println("sameTile");
        Tile comp = null;
        Tile instance = new Tile();
        boolean expResult = false;
        boolean result = instance.sameTile(comp);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of DoubleSide method, of class Tile.
     */
    @Test
    public void testDoubleSide() {
        System.out.println("DoubleSide");
        Tile instance = new Tile();
        boolean expResult = false;
        boolean result = instance.DoubleSide();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printHorizontal method, of class Tile.
     */
    @Test
    public void testPrintHorizontal() {
        System.out.println("printHorizontal");
        Tile instance = new Tile();
        String expResult = "";
        String result = instance.printHorizontal();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printVertical method, of class Tile.
     */
    @Test
    public void testPrintVertical() {
        System.out.println("printVertical");
        Tile instance = new Tile();
        instance.printVertical();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
