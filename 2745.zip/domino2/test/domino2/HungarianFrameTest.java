/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class HungarianFrameTest {
    
    public HungarianFrameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of win method, of class HungarianFrame.
     */
    @Test
    public void testWin() {
        System.out.println("win");
        int a = 0;
        HungarianFrame instance = new HungarianFrame();
        instance.win(a);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playBot method, of class HungarianFrame.
     */
    @Test
    public void testPlayBot() {
        System.out.println("playBot");
        Player bot = null;
        HungarianFrame instance = new HungarianFrame();
        instance.playBot(bot);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loop method, of class HungarianFrame.
     */
    @Test
    public void testLoop() {
        System.out.println("loop");
        int a = 0;
        HungarianFrame instance = new HungarianFrame();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of play method, of class HungarianFrame.
     */
    @Test
    public void testPlay() {
        System.out.println("play");
        int num = 0;
        HungarianFrame instance = new HungarianFrame();
        instance.play(num);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playPlayer method, of class HungarianFrame.
     */
    @Test
    public void testPlayPlayer() {
        System.out.println("playPlayer");
        Player p = null;
        HungarianFrame instance = new HungarianFrame();
        instance.playPlayer(p);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTile method, of class HungarianFrame.
     */
    @Test
    public void testGetTile() {
        System.out.println("getTile");
        int number = 0;
        HungarianFrame instance = new HungarianFrame();
        Tile expResult = null;
        Tile result = instance.getTile(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTable method, of class HungarianFrame.
     */
    @Test
    public void testPrintTable() {
        System.out.println("printTable");
        HungarianFrame instance = new HungarianFrame();
        instance.printTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTiles method, of class HungarianFrame.
     */
    @Test
    public void testPrintTiles() {
        System.out.println("printTiles");
        HungarianFrame instance = new HungarianFrame();
        instance.printTiles();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of visibleTile method, of class HungarianFrame.
     */
    @Test
    public void testVisibleTile() {
        System.out.println("visibleTile");
        int t = 0;
        HungarianFrame instance = new HungarianFrame();
        instance.visibleTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of unenableTile method, of class HungarianFrame.
     */
    @Test
    public void testUnenableTile() {
        System.out.println("unenableTile");
        int t = 0;
        HungarianFrame instance = new HungarianFrame();
        instance.unenableTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enableTile method, of class HungarianFrame.
     */
    @Test
    public void testEnableTile() {
        System.out.println("enableTile");
        int t = 0;
        HungarianFrame instance = new HungarianFrame();
        instance.enableTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class HungarianFrame.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        HungarianFrame.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
