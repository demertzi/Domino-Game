/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class Solo1Test {
    
    public Solo1Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of splitLists method, of class Solo1.
     */
    @Test
    public void testSplitLists() {
        System.out.println("splitLists");
        Solo1 instance = new Solo1();
        instance.splitLists();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getList1 method, of class Solo1.
     */
    @Test
    public void testGetList1() {
        System.out.println("getList1");
        Solo1 instance = new Solo1();
        ArrayList<Tile> expResult = null;
        ArrayList<Tile> result = instance.getList1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getList2 method, of class Solo1.
     */
    @Test
    public void testGetList2() {
        System.out.println("getList2");
        Solo1 instance = new Solo1();
        ArrayList<Tile> expResult = null;
        ArrayList<Tile> result = instance.getList2();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getList3 method, of class Solo1.
     */
    @Test
    public void testGetList3() {
        System.out.println("getList3");
        Solo1 instance = new Solo1();
        ArrayList<Tile> expResult = null;
        ArrayList<Tile> result = instance.getList3();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getList4 method, of class Solo1.
     */
    @Test
    public void testGetList4() {
        System.out.println("getList4");
        Solo1 instance = new Solo1();
        ArrayList<Tile> expResult = null;
        ArrayList<Tile> result = instance.getList4();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTheLastTile method, of class Solo1.
     */
    @Test
    public void testGetTheLastTile() {
        System.out.println("getTheLastTile");
        ArrayList<Tile> list = null;
        Solo1 instance = new Solo1();
        Tile expResult = null;
        Tile result = instance.getTheLastTile(list);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeTile method, of class Solo1.
     */
    @Test
    public void testRemoveTile() {
        System.out.println("removeTile");
        ArrayList<Tile> list = null;
        int t = 0;
        Solo1 instance = new Solo1();
        instance.removeTile(list, t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enableTile method, of class Solo1.
     */
    @Test
    public void testEnableTile() {
        System.out.println("enableTile");
        Tile t = null;
        Solo1 instance = new Solo1();
        boolean expResult = false;
        boolean result = instance.enableTile(t);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of numberOfTilesList method, of class Solo1.
     */
    @Test
    public void testNumberOfTilesList() {
        System.out.println("numberOfTilesList");
        ArrayList<Tile> list = null;
        Solo1 instance = new Solo1();
        int expResult = 0;
        int result = instance.numberOfTilesList(list);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
