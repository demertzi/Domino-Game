/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class ScoreTest {
    
    public ScoreTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of updateScore method, of class Score.
     */
    @Test
    public void testUpdateScore() {
        System.out.println("updateScore");
        Score instance = new Score();
        instance.updateScore();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getScore1 method, of class Score.
     */
    @Test
    public void testGetScore1() {
        System.out.println("getScore1");
        Score instance = new Score();
        int expResult = 0;
        int result = instance.getScore1();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getScore2 method, of class Score.
     */
    @Test
    public void testGetScore2() {
        System.out.println("getScore2");
        Score instance = new Score();
        int expResult = 0;
        int result = instance.getScore2();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getScore3 method, of class Score.
     */
    @Test
    public void testGetScore3() {
        System.out.println("getScore3");
        Score instance = new Score();
        int expResult = 0;
        int result = instance.getScore3();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getScore4 method, of class Score.
     */
    @Test
    public void testGetScore4() {
        System.out.println("getScore4");
        Score instance = new Score();
        int expResult = 0;
        int result = instance.getScore4();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRound method, of class Score.
     */
    @Test
    public void testGetRound() {
        System.out.println("getRound");
        Score instance = new Score();
        int expResult = 0;
        int result = instance.getRound();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of checkWinner method, of class Score.
     */
    @Test
    public void testCheckWinner() {
        System.out.println("checkWinner");
        Score instance = new Score();
        boolean expResult = false;
        boolean result = instance.checkWinner();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getWinner method, of class Score.
     */
    @Test
    public void testGetWinner() {
        System.out.println("getWinner");
        Score instance = new Score();
        Player expResult = null;
        Player result = instance.getWinner();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
