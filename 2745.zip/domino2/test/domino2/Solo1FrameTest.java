/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class Solo1FrameTest {
    
    public Solo1FrameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of enableTile method, of class Solo1Frame.
     */
    @Test
    public void testEnableTile() {
        System.out.println("enableTile");
        Tile t = null;
        Solo1Frame instance = new Solo1Frame();
        boolean expResult = false;
        boolean result = instance.enableTile(t);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of remove method, of class Solo1Frame.
     */
    @Test
    public void testRemove() {
        System.out.println("remove");
        Tile t = null;
        Solo1Frame instance = new Solo1Frame();
        instance.remove(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getIntTile method, of class Solo1Frame.
     */
    @Test
    public void testGetTile() {
        System.out.println("getTile");
        int num = 0;
        Solo1Frame instance = new Solo1Frame();
        Tile expResult = null;
        Tile result = instance.getIntTile(num);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of putTileOnTable method, of class Solo1Frame.
     */
    @Test
    public void testPutTileOnTable() {
        System.out.println("putTileOnTable");
        int num = 0;
        Solo1Frame instance = new Solo1Frame();
        instance.putTileOnTable(num);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTable method, of class Solo1Frame.
     */
    @Test
    public void testPrintTable() {
        System.out.println("printTable");
        Solo1Frame instance = new Solo1Frame();
        instance.printTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createNshuffleTiles method, of class Solo1Frame.
     */
    @Test
    public void testCreateNshuffleTiles() {
        System.out.println("createNshuffleTiles");
        Solo1Frame instance = new Solo1Frame();
        instance.createNshuffleTiles();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Solo1Frame.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Solo1Frame.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getIntTile method, of class Solo1Frame.
     */
    @Test
    public void testGetIntTile() {
        System.out.println("getIntTile");
        int a = 0;
        Solo1Frame instance = new Solo1Frame();
        int expResult = 0;
        int result = instance.getIntTile(a);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getIndexTile method, of class Solo1Frame.
     */
    @Test
    public void testGetIndexTile() {
        System.out.println("getIndexTile");
        int a = 0;
        Solo1Frame instance = new Solo1Frame();
        int expResult = 0;
        int result = instance.getIndexTile(a);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tileUnenable method, of class Solo1Frame.
     */
    @Test
    public void testTileUnenable() {
        System.out.println("tileUnenable");
        int i = 0;
        Solo1Frame instance = new Solo1Frame();
        instance.tileUnenable(i);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tileEnable method, of class Solo1Frame.
     */
    @Test
    public void testTileEnable() {
        System.out.println("tileEnable");
        int i = 0;
        Solo1Frame instance = new Solo1Frame();
        instance.tileEnable(i);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
