/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class PackTest {
    
    public PackTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDominos method, of class Pack.
     */
    @Test
    public void testGetDominos() {
        System.out.println("getDominos");
        Pack instance = null;
        List<Tile> expResult = null;
        List<Tile> result = instance.getDominos();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of shuffle method, of class Pack.
     */
    @Test
    public void testShuffle() {
        System.out.println("shuffle");
        Pack instance = null;
        instance.shuffle();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPackSize method, of class Pack.
     */
    @Test
    public void testGetPackSize() {
        System.out.println("getPackSize");
        Pack instance = null;
        int expResult = 0;
        int result = instance.getPackSize();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getspecificDominos method, of class Pack.
     */
    @Test
    public void testGetspecificDominos() {
        System.out.println("getspecificDominos");
        int z = 0;
        Pack instance = null;
        Tile expResult = null;
        Tile result = instance.getspecificDominos(z);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
