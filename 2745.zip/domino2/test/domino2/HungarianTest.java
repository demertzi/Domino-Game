/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class HungarianTest {
    
    public HungarianTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of firstTurn method, of class Hungarian.
     */
    @Test
    public void testFirstTurn() {
        System.out.println("firstTurn");
        int num = 0;
        Hungarian instance = null;
        Player expResult = null;
        Player result = instance.firstTurn(num);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of secondTurn method, of class Hungarian.
     */
    @Test
    public void testSecondTurn() {
        System.out.println("secondTurn");
        int num = 0;
        Hungarian instance = null;
        Player expResult = null;
        Player result = instance.secondTurn(num);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of thirdTurn method, of class Hungarian.
     */
    @Test
    public void testThirdTurn() {
        System.out.println("thirdTurn");
        int num = 0;
        Hungarian instance = null;
        Player expResult = null;
        Player result = instance.thirdTurn(num);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of fourthTurn method, of class Hungarian.
     */
    @Test
    public void testFourthTurn() {
        System.out.println("fourthTurn");
        int num = 0;
        Hungarian instance = null;
        Player expResult = null;
        Player result = instance.fourthTurn(num);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of userTurn method, of class Hungarian.
     */
    @Test
    public void testUserTurn() {
        System.out.println("userTurn");
        int num = 0;
        Hungarian instance = null;
        boolean expResult = false;
        boolean result = instance.userTurn(num);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of putToSide method, of class Hungarian.
     */
    @Test
    public void testPutToSide() {
        System.out.println("putToSide");
        Tile t = null;
        Hungarian instance = null;
        boolean expResult = false;
        boolean result = instance.putToSide(t);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getShouldFlip method, of class Hungarian.
     */
    @Test
    public void testGetShouldFlip() {
        System.out.println("getShouldFlip");
        Hungarian instance = null;
        boolean expResult = false;
        boolean result = instance.getShouldFlip();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of putTileOnTable method, of class Hungarian.
     */
    @Test
    public void testPutTileOnTable() {
        System.out.println("putTileOnTable");
        Tile t = null;
        Hungarian instance = null;
        instance.putTileOnTable(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bot method, of class Hungarian.
     */
    @Test
    public void testBot() {
        System.out.println("bot");
        Player player = null;
        boolean first = false;
        Hungarian instance = null;
        instance.bot(player, first);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
