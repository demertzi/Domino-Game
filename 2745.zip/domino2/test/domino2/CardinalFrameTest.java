/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class CardinalFrameTest {
    
    public CardinalFrameTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class CardinalFrame.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        CardinalFrame.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of play method, of class CardinalFrame.
     */
    @Test
    public void testPlay() {
        System.out.println("play");
        int num = 0;
        CardinalFrame instance = new CardinalFrame();
        instance.play(num);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playBot method, of class CardinalFrame.
     */
    @Test
    public void testPlayBot() {
        System.out.println("playBot");
        Player bot = null;
        CardinalFrame instance = new CardinalFrame();
        instance.playBot(bot);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of visibleTile method, of class CardinalFrame.
     */
    @Test
    public void testVisibleTile() {
        System.out.println("visibleTile");
        int t = 0;
        CardinalFrame instance = new CardinalFrame();
        instance.visibleTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of unenableTile method, of class CardinalFrame.
     */
    @Test
    public void testUnenableTile() {
        System.out.println("unenableTile");
        int t = 0;
        CardinalFrame instance = new CardinalFrame();
        instance.unenableTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of enableTile method, of class CardinalFrame.
     */
    @Test
    public void testEnableTile() {
        System.out.println("enableTile");
        int t = 0;
        CardinalFrame instance = new CardinalFrame();
        instance.enableTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTile method, of class CardinalFrame.
     */
    @Test
    public void testGetTile() {
        System.out.println("getTile");
        int number = 0;
        CardinalFrame instance = new CardinalFrame();
        Tile expResult = null;
        Tile result = instance.getTile(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playPlayer method, of class CardinalFrame.
     */
    @Test
    public void testPlayPlayer() {
        System.out.println("playPlayer");
        Player p = null;
        CardinalFrame instance = new CardinalFrame();
        instance.playPlayer(p);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTable method, of class CardinalFrame.
     */
    @Test
    public void testPrintTable() {
        System.out.println("printTable");
        CardinalFrame instance = new CardinalFrame();
        instance.printTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printTiles method, of class CardinalFrame.
     */
    @Test
    public void testPrintTiles() {
        System.out.println("printTiles");
        CardinalFrame instance = new CardinalFrame();
        instance.printTiles();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
