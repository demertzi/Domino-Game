/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domino2;

import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author demer
 */
public class PlayerTest {
    
    public PlayerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of createHand method, of class Player.
     */
    @Test
    public void testCreateHand() {
        System.out.println("createHand");
        int number = 0;
        Player instance = null;
        instance.createHand(number);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class Player.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        Player instance = null;
        String expResult = "";
        String result = instance.getName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHand method, of class Player.
     */
    @Test
    public void testGetHand() {
        System.out.println("getHand");
        Player instance = null;
        List<Tile> expResult = null;
        List<Tile> result = instance.getHand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getsHand method, of class Player.
     */
    @Test
    public void testGetsHand() {
        System.out.println("getsHand");
        Player instance = null;
        List<Tile> expResult = null;
        List<Tile> result = instance.getsHand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of shuffleHand method, of class Player.
     */
    @Test
    public void testShuffleHand() {
        System.out.println("shuffleHand");
        Player instance = null;
        instance.shuffleHand();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of numberOfTilesInHand method, of class Player.
     */
    @Test
    public void testNumberOfTilesInHand() {
        System.out.println("numberOfTilesInHand");
        Player instance = null;
        int expResult = 0;
        int result = instance.numberOfTilesInHand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of emptyHand method, of class Player.
     */
    @Test
    public void testEmptyHand() {
        System.out.println("emptyHand");
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.emptyHand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getIndex method, of class Player.
     */
    @Test
    public void testGetIndex() {
        System.out.println("getIndex");
        Tile t = null;
        Player instance = null;
        int expResult = 0;
        int result = instance.getIndex(t);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeTile method, of class Player.
     */
    @Test
    public void testRemoveTile() {
        System.out.println("removeTile");
        Tile t = null;
        Player instance = null;
        instance.removeTile(t);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of hasTile method, of class Player.
     */
    @Test
    public void testHasTile() {
        System.out.println("hasTile");
        Tile t = null;
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.hasTile(t);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of canPlay method, of class Player.
     */
    @Test
    public void testCanPlay() {
        System.out.println("canPlay");
        int s = 0;
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.canPlay(s);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of canPlayOnTable method, of class Player.
     */
    @Test
    public void testCanPlayOnTable() {
        System.out.println("canPlayOnTable");
        Table table = null;
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.canPlayOnTable(table);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of valueHand method, of class Player.
     */
    @Test
    public void testValueHand() {
        System.out.println("valueHand");
        Player instance = null;
        int expResult = 0;
        int result = instance.valueHand();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tileFromHand method, of class Player.
     */
    @Test
    public void testTileFromHand() {
        System.out.println("tileFromHand");
        int number = 0;
        Player instance = null;
        Tile expResult = null;
        Tile result = instance.tileFromHand(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of theBiggestDouble method, of class Player.
     */
    @Test
    public void testTheBiggestDouble() {
        System.out.println("theBiggestDouble");
        Player instance = null;
        int expResult = 0;
        int result = instance.theBiggestDouble();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of playersHighestSumTile method, of class Player.
     */
    @Test
    public void testPlayersHighestSumTile() {
        System.out.println("playersHighestSumTile");
        Player instance = null;
        int expResult = 0;
        int result = instance.playersHighestSumTile();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of canPlayCardinal method, of class Player.
     */
    @Test
    public void testCanPlayCardinal() {
        System.out.println("canPlayCardinal");
        int s = 0;
        Player instance = null;
        boolean expResult = false;
        boolean result = instance.canPlayCardinal(s);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tileFromHandCardinal method, of class Player.
     */
    @Test
    public void testTileFromHandCardinal() {
        System.out.println("tileFromHandCardinal");
        int number = 0;
        Player instance = null;
        Tile expResult = null;
        Tile result = instance.tileFromHandCardinal(number);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
